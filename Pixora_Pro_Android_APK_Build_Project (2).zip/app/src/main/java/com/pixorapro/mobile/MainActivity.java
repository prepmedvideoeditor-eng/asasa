package com.pixorapro.mobile;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.graphics.Color;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private static final int CHOOSE_FILE = 2001;
    private final Map<String, Transfer> transfers = new HashMap<>();

    private static class Transfer {
        final File temp;
        final FileOutputStream stream;
        final String filename;
        final String mime;
        long count = 0;
        Transfer(File f, FileOutputStream s, String filename, String mime) {
            temp = f; stream = s; this.filename = filename; this.mime = mime;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,12,22));
        getWindow().setNavigationBarColor(Color.rgb(8,12,22));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,12,22));
        setContentView(web);
        WebSettings w = web.getSettings();
        w.setJavaScriptEnabled(true);
        w.setDomStorageEnabled(true);
        w.setAllowFileAccess(true);
        w.setAllowContentAccess(true);
        w.setMediaPlaybackRequiresUserGesture(false);
        w.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(), "PixoraAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Native download bridge. The underlying Pixora editor HTML/CSS/JS is unchanged.
                web.evaluateJavascript(DOWNLOAD_HOOK, null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(params.createIntent(), CHOOSE_FILE); return true; }
                catch (Exception ex) {
                    chooser = null;
                    toast("Unable to open photo picker");
                    return false;
                }
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data);
        if (req == CHOOSE_FILE && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));
            chooser = null;
        }
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(this,message, Toast.LENGTH_LONG).show());
    }

    private final class Bridge {
        @JavascriptInterface public synchronized String start(String raw, String mime) {
            try {
                String filename = raw.replaceAll("[^a-zA-Z0-9_. -]", "_");
                if (filename.length() == 0) filename = "Pixora_export.png";
                if (filename.length() > 120) filename = filename.substring(filename.length()-120);
                String ext = filename.toLowerCase(Locale.ROOT);
                if (!(ext.endsWith(".png") || ext.endsWith(".jpg") || ext.endsWith(".jpeg") ||
                        ext.endsWith(".gif") || ext.endsWith(".pdf") || ext.endsWith(".pxr"))) {
                    filename += ".png";
                }
                String id = UUID.randomUUID().toString();
                File f = File.createTempFile("pixora_", ".tmp", getCacheDir());
                transfers.put(id, new Transfer(f, new FileOutputStream(f), filename, mime));
                return id;
            } catch (Exception ex) { toast("Could not start export"); return ""; }
        }
        @JavascriptInterface public synchronized void chunk(String id, String base64) {
            Transfer t = transfers.get(id);
            if (t == null) return;
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                t.count += bytes.length;
                if (t.count > 250L * 1024 * 1024) throw new IllegalStateException("File too large");
                t.stream.write(bytes);
            } catch (Exception ex) {
                abort(id);
                toast("Export failed: insufficient storage or memory");
            }
        }
        @JavascriptInterface public synchronized void finish(String id) {
            Transfer t = transfers.remove(id);
            if (t == null) return;
            try {
                t.stream.close();
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME,t.filename);
                values.put(MediaStore.MediaColumns.MIME_TYPE,t.mime.isEmpty()?"application/octet-stream":t.mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Pixora Pro");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Downloads not available");
                try (InputStream in = new FileInputStream(t.temp);
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Cannot write file");
                    byte[] buf = new byte[64*1024];
                    int n;
                    while ((n = in.read(buf)) != -1) out.write(buf,0,n);
                } catch (Exception ex) {
                    getContentResolver().delete(uri,null,null);
                    throw ex;
                }
                toast("Saved to Downloads / Pixora Pro: " + t.filename);
            } catch (Exception ex) { toast("Could not save export"); }
            finally { t.temp.delete(); }
        }
        @JavascriptInterface public synchronized void abort(String id) {
            Transfer t = transfers.remove(id);
            if (t != null) {
                try { t.stream.close(); } catch (Exception ignored) {}
                t.temp.delete();
            }
        }
    }

    private static final String DOWNLOAD_HOOK = "(function(){" +
            "if(window.__pixoraNativeDownload)return;window.__pixoraNativeDownload=true;" +
            "document.addEventListener('click',async function(e){" +
            "var a=e.target.closest&&e.target.closest('a[download]');" +
            "if(!a||!a.href.startsWith('blob:'))return;" +
            "e.preventDefault();e.stopImmediatePropagation();" +
            "var id='';try{" +
            "var b=await(await fetch(a.href)).blob();" +
            "id=PixoraAndroid.start(a.download||'Pixora_export.png',b.type||'application/octet-stream');" +
            "if(!id)throw Error('Could not start download');" +
            "for(var p=0;p<b.size;p+=98304){" +
            "var data=new Uint8Array(await b.slice(p,p+98304).arrayBuffer());" +
            "var s='';for(var j=0;j<data.length;j++)s+=String.fromCharCode(data[j]);" +
            "PixoraAndroid.chunk(id,btoa(s));" +
            "}" +
            "PixoraAndroid.finish(id);" +
            "}catch(err){if(id)PixoraAndroid.abort(id);console.error(err);alert('Could not export file: '+err.message);}" +
            "},true);" +
            "})();";
}
