# Pixora Pro v3 — Android APK Build Project

এটি **Android Studio / GitHub Actions দিয়ে APK build করার source project**, এখনো তৈরি APK নয়। মূল Pixora Pro v3-এর HTML, CSS, JavaScript এবং interface একেবারে অপরিবর্তিত রাখা হয়েছে। Native Android wrapper কেবল photo picker এবং Downloads-এ PNG/JPG/GIF/PDF/PXR save করার সুবিধা যোগ করে।

## সহজ পদ্ধতি: GitHub Actions (নিজের কম্পিউটারে Android SDK না লাগলেও)

1. GitHub-এ নতুন empty repository বানান। ZIP extract করে ভিতরের সব file repository-তে upload করুন (hidden `.github` folder-সহ)।
2. Repository-এর **Actions** tab-এ যান, **Build Pixora Pro Android APK** workflow বাছুন, **Run workflow** চাপুন। Workflow main branch-এ push করলেও চলবে।
3. Build successful হলে run-এর নিচে **Artifacts → Pixora-Pro-v3-APK** download করুন। ZIP-এর ভিতর `app-debug.apk` থাকবে।
4. APK Android 10+ ফোনে install করুন। Settings-এ unknown apps installation allow করতে হতে পারে।

## Android Studio

Android Studio-তে project folder open করুন। JDK 17 / Gradle 8.7 / Android SDK platform 35 দিয়ে Sync করুন। **Build → Build APK(s)**, তারপর `app/build/outputs/apk/debug/app-debug.apk`।

## কী আছে এবং কী নেই

- Photo upload: Android system file picker
- Native download: `Downloads/Pixora Pro` folder
- Editor: মূল Pixora Pro v3 হুবহু একই, project canvas +60% enlarged as before
- AI cutout: external online model / network availability dependent, same as v3
- AI background: preset-based, not true generative AI, same as v3
- Android 10+ (API 29+). This is a native WebView shell for the HTML editor, not a rebuilt native graphics engine.
- This package has **not been compiled or device-tested here**, as this environment has no Android SDK / Gradle distributions.
